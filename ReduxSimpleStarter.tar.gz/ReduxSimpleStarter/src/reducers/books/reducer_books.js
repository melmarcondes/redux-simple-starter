export default function () {
    return[
        {title: 'Javascript Bla bla'},
        {title: 'Java for Beginners'},
        {title: 'NodeJS for Dummies'},
        {title: 'Harry Potter'}
    ]
}